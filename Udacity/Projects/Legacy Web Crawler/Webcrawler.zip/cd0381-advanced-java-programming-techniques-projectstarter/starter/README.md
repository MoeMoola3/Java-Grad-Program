# Purpose of this Folder

This folder contains the scaffolded project files to get a student started on their project.
