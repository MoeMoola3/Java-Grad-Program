module Security {
    requires miglayout.swing;
    requires java.desktop;
    requires Image;
    requires java.prefs;
    requires com.google.gson;
    requires com.google.common;
}