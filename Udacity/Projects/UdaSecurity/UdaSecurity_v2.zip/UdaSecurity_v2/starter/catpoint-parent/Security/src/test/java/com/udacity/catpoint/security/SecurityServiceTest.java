package com.udacity.catpoint.security;

import com.udacity.catpoint.image.service.FakeImageService;
import com.udacity.catpoint.security.application.StatusListener;
import com.udacity.catpoint.security.data.*;
import com.udacity.catpoint.security.service.SecurityService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
public class SecurityServiceTest {

    @Mock
    private Sensor sensor;

    @Mock
    private StatusListener statusListener;
    @Mock
    private SecurityRepository securityRepository;

    @Mock
    private FakeImageService imageService;

    @InjectMocks
    private SecurityService securityService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    // Test 1
    @Test
    public void test_if_AlarmArmed_and_SensorActivated_SetSystem_PendingAlarmStatus() {
        when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME); //Why does this one only give me a null exception

        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);

        Sensor sensor1 = new Sensor("Sensor1", SensorType.DOOR);
        securityService.addSensor(sensor1);
        securityService.changeSensorActivationStatus(sensor1, true);

        verify(securityRepository).setAlarmStatus(AlarmStatus.PENDING_ALARM);
    }

    // Test 2
    @Test
    public void test_if_AlarmArmed_and_SensorActivated_and_SystemPending_SetSystem_toAlarm(){
        when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);

        Sensor sensor1 = new Sensor("Sensor1", SensorType.DOOR);
        securityService.addSensor(sensor1);
        securityService.changeSensorActivationStatus(sensor1, true);

        verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
    }

    // Test 3
    @Test
    public void test_if_PendingAlarm_and_AllSensorsInactive_return_NoAlarmState(){
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);

        Set<Sensor> sensors = new HashSet<>();
        Sensor sensor1 = new Sensor("Sensor1", SensorType.DOOR);
        Sensor sensor2 = new Sensor("Sensor2", SensorType.WINDOW);
        Sensor sensor3 = new Sensor("Sensor3", SensorType.MOTION);
        sensors.add(sensor1);
        sensors.add(sensor2);
        sensors.add(sensor3);

        sensors.forEach(sensor -> sensor.setActive(true));

        securityService.changeSensorActivationStatus(sensor1, false);
        securityService.changeSensorActivationStatus(sensor2, false);
        securityService.changeSensorActivationStatus(sensor3, false);

        verify(securityRepository, times(3)).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    // Test 4
    @Test
    public void test_if_AlarmIsActive_ChangeInSensorState_NoEffect_for_AlarmState(){
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);

        Sensor sensor1 = new Sensor("Sensor1", SensorType.DOOR);
        securityService.changeSensorActivationStatus(sensor1, true);
        securityService.changeSensorActivationStatus(sensor1, false);

        verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
    }

    // Test 5
    @Test
    public void test_if_SensorIsActivated_WhileActiveState_and_SystemInPendingState_then_SetAlarmState(){
        //If a sensor is activated while already active and the system is in pending state, change it to alarm state.
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);

        Sensor sensor1 = new Sensor("Sensor1", SensorType.DOOR);
        securityService.changeSensorActivationStatus(sensor1, true);
        securityService.changeSensorActivationStatus(sensor1, true);

        verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
    }

    //Test 6
    @Test
    public void test_if_SensorIsDeactivated_WhileInactive_MakeNoChangesToAlarmState(){
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);

        Sensor sensor1 = new Sensor("Sensor1", SensorType.DOOR);
        securityService.changeSensorActivationStatus(sensor1, false);

        verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);

    }

    // Test 7
    @Test
    public void test_if_CatIdentified_WhileSystemArmedHome_then_SetAlarmStatus(){
        when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);

        securityService.processImage(mock(BufferedImage.class));

        verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
    }

    // Test 8
    @Test
    public void test_if_CatNotIdentified_and_SensorsNotActive_SetNoAlarmStatus(){

        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(false);

        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM); // Set the default value to NO_ALARM
        securityService.processImage(mock(BufferedImage.class));


        Sensor sensor1 = new Sensor("Sensor1", SensorType.DOOR);
        Sensor sensor2 = new Sensor("Sensor2", SensorType.WINDOW);

        securityService.addSensor(sensor1);
        securityService.addSensor(sensor2);

        securityService.changeSensorActivationStatus(sensor1, false);
        securityService.changeSensorActivationStatus(sensor2, false);

        verify(securityRepository).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    // Test 9
    @Test
    public void test_if_SystemIsArmed_SetNoAlarmStatus(){
       securityService.setArmingStatus(ArmingStatus.DISARMED);

       verify(securityRepository).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    // Test 10
    @ParameterizedTest
    @EnumSource(value = ArmingStatus.class, names = {"ARMED_AWAY", "ARMED_HOME"})
    public void test_if_SystemIsArmed_ResetAllSensors_to_Inactive(ArmingStatus armingStatus){


        // Create 3 Sensors
        Set<Sensor> sensors = new HashSet<>();
        Sensor sensor1 = new Sensor("Sensor1", SensorType.DOOR);
        Sensor sensor2 = new Sensor("Sensor2", SensorType.WINDOW);
        Sensor sensor3 = new Sensor("Sensor3", SensorType.MOTION);
        sensors.add(sensor1);
        sensors.add(sensor2);
        sensors.add(sensor3);

        sensors.forEach(sensor -> {
            sensor.setActive(true);
            securityService.addSensor(sensor);
        });

        securityService.setArmingStatus(armingStatus);


        securityService.getSensors().forEach(sensor -> {
                    Assertions.assertFalse(sensor.getActive());
        });

    }

    // Test 11
    @ParameterizedTest
    @EnumSource(value = ArmingStatus.class, names = {"ARMED_AWAY", "DISARMED"})
    public void test_if_SystemIsArmedHome_While_ContainsCat_SetAlarmStatus(ArmingStatus armingStatus){
        when(securityRepository.getArmingStatus()).thenReturn(armingStatus);
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        securityService.processImage(mock(BufferedImage.class));

        securityService.setArmingStatus(ArmingStatus.ARMED_HOME);


        verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);

    }

    @Test
    public void test_addStatusListener(){
        securityService.addStatusListener(statusListener);
    }

    @Test
    public void test_removeStatusListener(){
        securityService.removeStatusListener(statusListener);
    }

    @Test
    public void test_if_SensorIsDeactivated_WhileInactive_MakeNoChangesToPendingState(){
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);

        Sensor sensor1 = new Sensor("Sensor1", SensorType.DOOR);
        securityService.changeSensorActivationStatus(sensor1, false);

        verify(securityRepository).setAlarmStatus(AlarmStatus.PENDING_ALARM);
    }

    @Test
    public void test_if_SensorIsDeactivated_WhileInactive_MakeNoChangesTonNoAlarmState(){
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);

        Sensor sensor1 = new Sensor("Sensor1", SensorType.DOOR);
        securityService.changeSensorActivationStatus(sensor1, false);

        verify(securityRepository).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

}